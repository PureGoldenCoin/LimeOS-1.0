#!/bin/bash

echo "🍋 Installing LimeOS dependencies..."

# Install Homebrew if missing
if ! command -v brew &> /dev/null
then
    echo "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Install dependencies
brew install nasm
brew install qemu
brew install i686-elf-gcc
brew install i686-elf-binutils
brew install i686-elf-grub
brew install xorriso
brew install dosfstools

echo "🍋 Dependencies installed."

# Fix Makefile for macOS GRUB
sed -i '' 's/grub-mkrescue/i686-elf-grub-mkrescue/g' Makefile 2>/dev/null

# Create hidden disk folder
mkdir -p ~/Desktop/"SCREENSHOT 12.385.67"

# Create disk image if missing
if [ ! -f ~/Desktop/"SCREENSHOT 12.385.67"/disk.img ]; then
    dd if=/dev/zero of=~/Desktop/"SCREENSHOT 12.385.67"/disk.img bs=512 count=65536
fi

echo "🍋 LimeOS setup complete."