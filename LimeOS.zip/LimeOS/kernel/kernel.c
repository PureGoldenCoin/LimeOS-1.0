/* LimeOS kernel.c - v0.6
   Features: .log activity log, .cfg prompt config,
             .md editor with Ctrl+B/U/I formatting,
             .sh script runner */

/* ── VGA ── */
#define VGA_COLS  80
#define VGA_ROWS  25
#define VGA_BLACK 0x00
#define VGA_WHITE 0x0F
#define VGA_LIME  0x0A
#define VGA_GRAY  0x08
#define VGA_CYAN  0x0B
#define VGA_BOLD  0x0F   /* bright white  */
#define VGA_UNDER 0x0B   /* cyan = underline */
#define VGA_ITAL  0x07   /* dark white = italic */

static unsigned short *vga = (unsigned short *)0xB8000;
static int cur_col=0, cur_row=0;

static void vga_put(int r,int c,char ch,unsigned char color){
    vga[r*VGA_COLS+c]=(unsigned short)ch|((unsigned short)color<<8);
}
static void clear_screen(void){
    for(int i=0;i<VGA_ROWS*VGA_COLS;i++) vga[i]=' '|(VGA_BLACK<<8);
    cur_col=cur_row=0;
}
static void scroll(void){
    for(int r=0;r<VGA_ROWS-1;r++)
        for(int c=0;c<VGA_COLS;c++)
            vga[r*VGA_COLS+c]=vga[(r+1)*VGA_COLS+c];
    for(int c=0;c<VGA_COLS;c++)
        vga[(VGA_ROWS-1)*VGA_COLS+c]=' '|(VGA_BLACK<<8);
}
static void putchar_color(char c,unsigned char color){
    if(c=='\n'){cur_col=0;cur_row++;}
    else if(c=='\b'){if(cur_col>0){cur_col--;vga_put(cur_row,cur_col,' ',VGA_BLACK);}return;}
    else{vga_put(cur_row,cur_col++,c,color);if(cur_col>=VGA_COLS){cur_col=0;cur_row++;}}
    if(cur_row>=VGA_ROWS){scroll();cur_row=VGA_ROWS-1;}
}
static void print_color(const char*s,unsigned char color){while(*s)putchar_color(*s++,color);}
static void print(const char*s){print_color(s,VGA_WHITE);}

/* ── Strings ── */
static int strcmp(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return *a-*b;}
static int strncmp(const char*a,const char*b,int n){while(n--&&*a&&*a==*b){a++;b++;}return n<0?0:*(unsigned char*)a-*(unsigned char*)b;}
static int strlen(const char*s){int n=0;while(s[n])n++;return n;}
static void strcpy_s(char*d,const char*s){while((*d++=*s++));}
static void memset_s(void*p,int v,int n){unsigned char*b=p;while(n--)*b++=(unsigned char)v;}
static void memcpy_s(void*d,const void*s,int n){unsigned char*dd=d;const unsigned char*ss=s;while(n--)*dd++=*ss++;}

/* get extension pointer */
static const char* get_ext(const char*name){
    int l=strlen(name),dot=-1;
    for(int i=l-1;i>=0;i--){if(name[i]=='.'){dot=i;break;}}
    return dot<0?name+l:name+dot;
}
static int has_valid_ext(const char*name){
    const char*e=get_ext(name);
    if(strcmp(e,".txt")==0)return 1;
    if(strcmp(e,".log")==0)return 1;
    if(strcmp(e,".cfg")==0)return 1;
    if(strcmp(e,".md")==0) return 1;
    if(strcmp(e,".sh")==0) return 1;
    return 0;
}

/* ── I/O ── */
static inline unsigned char inb(unsigned short p){unsigned char v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outb(unsigned short p,unsigned char v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}
static inline unsigned short inw(unsigned short p){unsigned short v;__asm__ volatile("inw %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outw(unsigned short p,unsigned short v){__asm__ volatile("outw %0,%1"::"a"(v),"Nd"(p));}

/* ── Keyboard ── */
static const char sc_lo[]={0,0,'1','2','3','4','5','6','7','8','9','0','-','=','\b','\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',0,'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\','z','x','c','v','b','n','m',',','.','/',0,'*',0,' '};
static const char sc_hi[]={0,0,'!','@','#','$','%','^','&','*','(',')','_','+','\b','\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',0,'A','S','D','F','G','H','J','K','L',':','"','~',0,'|','Z','X','C','V','B','N','M','<','>','?',0,'*',0,' '};
#define SC_LSHIFT 0x2A
#define SC_RSHIFT 0x36
#define SC_LCTRL  0x1D
static int shift_held=0;
static int ctrl_held=0;
static unsigned char read_sc(void){while(!(inb(0x64)&1));return inb(0x60);}
static char read_key(void){
    unsigned char sc=read_sc();
    if(sc==SC_LSHIFT||sc==SC_RSHIFT){shift_held=1;return 0;}
    if(sc==(SC_LSHIFT|0x80)||sc==(SC_RSHIFT|0x80)){shift_held=0;return 0;}
    if(sc==SC_LCTRL){ctrl_held=1;return 0;}
    if(sc==(SC_LCTRL|0x80)){ctrl_held=0;return 0;}
    if(sc&0x80)return 0;
    const char*map=shift_held?sc_hi:sc_lo;
    if(sc<(int)sizeof(sc_lo))return map[sc];
    return 0;
}

/* ── ATA PIO ── */
static int ata_ready=0;
static int ata_init(void){
    outb(0x1F6,0xA0);
    for(int i=0;i<10000;i++)inb(0x1F7);
    unsigned char st=inb(0x1F7);
    if(st==0x00||st==0xFF)return 0;
    ata_ready=1;return 1;
}
static void ata_wait_bsy(void){int t=100000;while((inb(0x1F7)&0x80)&&t--);}
static void ata_wait_drq(void){int t=100000;while(!(inb(0x1F7)&0x08)&&t--);}
static int disk_read_sector(unsigned int lba,unsigned char*buf){
    if(!ata_ready)return 0;
    ata_wait_bsy();
    outb(0x1F1,0x00);outb(0x1F2,1);
    outb(0x1F3,(unsigned char)lba);outb(0x1F4,(unsigned char)(lba>>8));
    outb(0x1F5,(unsigned char)(lba>>16));outb(0x1F6,0xE0|((lba>>24)&0x0F));
    outb(0x1F7,0x20);ata_wait_bsy();ata_wait_drq();
    if(inb(0x1F7)&0x01)return 0;
    for(int i=0;i<256;i++){unsigned short w=inw(0x1F0);buf[i*2]=(unsigned char)(w&0xFF);buf[i*2+1]=(unsigned char)(w>>8);}
    return 1;
}
static int disk_write_sector(unsigned int lba,const unsigned char*buf){
    if(!ata_ready)return 0;
    ata_wait_bsy();
    outb(0x1F1,0x00);outb(0x1F2,1);
    outb(0x1F3,(unsigned char)lba);outb(0x1F4,(unsigned char)(lba>>8));
    outb(0x1F5,(unsigned char)(lba>>16));outb(0x1F6,0xE0|((lba>>24)&0x0F));
    outb(0x1F7,0x30);ata_wait_bsy();ata_wait_drq();
    if(inb(0x1F7)&0x01)return 0;
    for(int i=0;i<256;i++){unsigned short w=(unsigned short)buf[i*2]|((unsigned short)buf[i*2+1]<<8);outw(0x1F0,w);}
    outb(0x1F7,0xE7);ata_wait_bsy();return 1;
}

/* ── LimeFS ── */
#define FS_SIG       "LIMEFS01"
#define MAX_FILES    16
#define FILE_SECTORS 4
#define MAX_FILESIZE (FILE_SECTORS*512)

typedef struct {
    char          name[16];
    unsigned int  size;
    unsigned char used;
    unsigned char pad[7];
} __attribute__((packed)) FEntry;

static unsigned char hdr[512];
static FEntry *ft=(FEntry*)(hdr+8);

static void fs_read_hdr(void){disk_read_sector(0,hdr);}
static void fs_write_hdr(void){disk_write_sector(0,hdr);}
static int  fs_check_sig(void){const char*s=FS_SIG;for(int i=0;i<8;i++)if(hdr[i]!=s[i])return 0;return 1;}
static void fs_format(void){
    memset_s(hdr,0,512);const char*s=FS_SIG;for(int i=0;i<8;i++)hdr[i]=s[i];fs_write_hdr();
    unsigned char blank[512];memset_s(blank,0,512);
    for(int i=0;i<MAX_FILES*FILE_SECTORS;i++)disk_write_sector(1+i,blank);
}
static void fs_init(void){if(!ata_ready)return;fs_read_hdr();if(!fs_check_sig())fs_format();}
static FEntry* fe_find(const char*name){for(int i=0;i<MAX_FILES;i++)if(ft[i].used==0xAA&&strcmp(ft[i].name,name)==0)return &ft[i];return 0;}
static FEntry* fe_alloc(void){for(int i=0;i<MAX_FILES;i++)if(ft[i].used!=0xAA)return &ft[i];return 0;}
static int     fe_index(FEntry*e){return (int)(e-ft);}
static void fe_read_data(FEntry*e,char*buf){
    unsigned int lba=1+(unsigned int)fe_index(e)*FILE_SECTORS,rem=e->size;
    for(int s=0;s<FILE_SECTORS&&rem>0;s++){
        unsigned char sec[512];disk_read_sector(lba+s,sec);
        unsigned int chunk=rem>512?512:rem;memcpy_s(buf+s*512,sec,chunk);rem-=chunk;
    }
}
static void fe_write_data(FEntry*e,const char*buf,unsigned int size){
    e->size=size;unsigned int lba=1+(unsigned int)fe_index(e)*FILE_SECTORS,rem=size;
    for(int s=0;s<FILE_SECTORS;s++){
        unsigned char sec[512];memset_s(sec,0,512);
        if(rem>0){unsigned int chunk=rem>512?512:rem;memcpy_s(sec,buf+s*512,chunk);rem-=chunk;}
        disk_write_sector(lba+s,sec);
    }
    fs_write_hdr();
}

/* ── Config (loaded from config.cfg on boot) ── */
#define MAX_PROMPT_NAME 24
static char  cfg_prompt_name[MAX_PROMPT_NAME]="lime";
static unsigned char cfg_prompt_color=VGA_LIME;

static unsigned char color_from_name(const char*n){
    if(strcmp(n,"green")==0||strcmp(n,"lime")==0) return VGA_LIME;
    if(strcmp(n,"white")==0)  return VGA_WHITE;
    if(strcmp(n,"cyan")==0)   return VGA_CYAN;
    if(strcmp(n,"gray")==0)   return VGA_GRAY;
    if(strcmp(n,"yellow")==0) return 0x0E;
    if(strcmp(n,"red")==0)    return 0x0C;
    if(strcmp(n,"blue")==0)   return 0x09;
    if(strcmp(n,"purple")==0) return 0x0D;
    return VGA_LIME;
}

/* parse key=value line */
static void cfg_parse_line(const char*line){
    /* prompt_name=xxx */
    if(strncmp(line,"prompt_name=",12)==0){
        const char*val=line+12;
        int i=0;
        while(val[i]&&val[i]!='\n'&&i<MAX_PROMPT_NAME-1){cfg_prompt_name[i]=val[i];i++;}
        cfg_prompt_name[i]=0;
    }
    /* prompt_color=xxx */
    else if(strncmp(line,"prompt_color=",13)==0){
        char col[16];int i=0;const char*val=line+13;
        while(val[i]&&val[i]!='\n'&&i<15){col[i]=val[i];i++;}col[i]=0;
        cfg_prompt_color=color_from_name(col);
    }
}

static void cfg_load(void){
    fs_read_hdr();
    FEntry*e=fe_find("config.cfg");
    if(!e||!e->size)return;
    static char cbuf[MAX_FILESIZE];
    memset_s(cbuf,0,MAX_FILESIZE);
    fe_read_data(e,cbuf);
    /* parse line by line */
    int i=0,sz=(int)e->size;
    while(i<sz){
        char line[64];int j=0;
        while(i<sz&&cbuf[i]!='\n'&&j<63){line[j++]=cbuf[i++];}
        if(i<sz&&cbuf[i]=='\n')i++;
        line[j]=0;
        if(j>0)cfg_parse_line(line);
    }
}

/* ── Activity log ── */
static unsigned int boot_tick=0; /* incremented per keystroke as crude clock */

static void log_append(const char*entry){
    fs_read_hdr();
    FEntry*e=fe_find("activity.log");
    if(!e){
        e=fe_alloc();
        if(!e)return;
        memset_s(e,0,sizeof(FEntry));
        strcpy_s(e->name,"activity.log");
        e->used=0xAA;e->size=0;
        fs_write_hdr();
    }
    static char lbuf[MAX_FILESIZE];
    memset_s(lbuf,0,MAX_FILESIZE);
    if(e->size>0)fe_read_data(e,lbuf);
    /* append entry if room */
    int cur=(int)e->size;
    int elen=strlen(entry);
    if(cur+elen+1<(int)MAX_FILESIZE){
        memcpy_s(lbuf+cur,entry,elen);
        lbuf[cur+elen]='\n';
        fe_write_data(e,lbuf,(unsigned int)(cur+elen+1));
    }
}

/* ── Editors ── */
static char ed_buf[MAX_FILESIZE];

/* shared header/footer drawing */
static void ed_draw_bar(int row, const char*text, unsigned char bg){
    unsigned char attr=(bg<<4)|0x0F;
    for(int c=0;c<VGA_COLS;c++) vga[row*VGA_COLS+c]=(unsigned short)' '|((unsigned short)attr<<8);
    for(int c=0;text[c]&&c<VGA_COLS;c++) vga[row*VGA_COLS+c]=(unsigned short)text[c]|((unsigned short)attr<<8);
}

/* ── Plain text editor (.txt .log .sh) ── */
static void txt_draw(const char*fname,int size,int cur){
    ed_draw_bar(0,fname,0x02);
    const char*h="[ESC=save+quit]";
    int hl=strlen(h);
    unsigned char attr=(0x02<<4)|0x0F;
    for(int c=0;c<hl;c++) vga[VGA_COLS-hl+c]=(unsigned short)h[c]|((unsigned short)attr<<8);

    int row=1,col=0;
    for(int i=0;i<=size&&row<VGA_ROWS-1;i++){
        if(i==size){if(i==cur)vga_put(row,col,'_',0x70);break;}
        unsigned char color=(i==cur)?0x70:VGA_WHITE;
        if(ed_buf[i]=='\n'){
            if(i==cur)vga_put(row,col,' ',0x70);
            while(col<VGA_COLS)vga_put(row,col++,' ',VGA_BLACK);
            row++;col=0;continue;
        }
        vga_put(row,col++,ed_buf[i],color);
        if(col>=VGA_COLS){col=0;row++;}
    }
    while(row<VGA_ROWS-1){while(col<VGA_COLS)vga_put(row,col++,' ',VGA_BLACK);col=0;row++;}
    ed_draw_bar(VGA_ROWS-1," arrows=move  ESC=save+quit",0x00);
}

static int txt_run(const char*fname,int size){
    int cur=size;
    txt_draw(fname,size,cur);
    while(1){
        unsigned char sc=read_sc();
        if(sc==SC_LSHIFT||sc==SC_RSHIFT){shift_held=1;continue;}
        if(sc==(SC_LSHIFT|0x80)||sc==(SC_RSHIFT|0x80)){shift_held=0;continue;}
        if(sc==SC_LCTRL){ctrl_held=1;continue;}
        if(sc==(SC_LCTRL|0x80)){ctrl_held=0;continue;}
        if(sc&0x80)continue;
        if(sc==0x01)break; /* ESC */
        if(sc==0x4B){if(cur>0)cur--;}
        else if(sc==0x4D){if(cur<size)cur++;}
        else if(sc==0x0E&&cur>0){for(int i=cur-1;i<size-1;i++)ed_buf[i]=ed_buf[i+1];size--;cur--;}
        else if(sc==0x1C&&size<(int)MAX_FILESIZE-1){for(int i=size;i>cur;i--)ed_buf[i]=ed_buf[i-1];ed_buf[cur]='\n';size++;cur++;}
        else{
            const char*map=shift_held?sc_hi:sc_lo;
            if(sc<(int)sizeof(sc_lo)&&map[sc]&&map[sc]!='\b'&&size<(int)MAX_FILESIZE-1){
                for(int i=size;i>cur;i--)ed_buf[i]=ed_buf[i-1];
                ed_buf[cur]=map[sc];size++;cur++;
            }
        }
        txt_draw(fname,size,cur);
    }
    return size;
}

/* ── Markdown editor (.md) with Ctrl+B/U/I toggles ──
   We store formatting as special marker bytes in the file:
   0x01 = bold toggle, 0x02 = italic toggle, 0x03 = underline toggle
   cat will render them as [B], [I], [U] indicators
   The editor shows them as color changes
── */
#define MD_BOLD  0x01
#define MD_ITAL  0x02
#define MD_UNDR  0x03

static unsigned char md_char_color(int pos, int size){
    /* scan from start to pos to determine active formatting */
    int bold=0,ital=0,undr=0;
    for(int i=0;i<pos&&i<size;i++){
        unsigned char c=(unsigned char)ed_buf[i];
        if(c==MD_BOLD)bold=!bold;
        else if(c==MD_ITAL)ital=!ital;
        else if(c==MD_UNDR)undr=!undr;
    }
    if(bold)return VGA_BOLD;
    if(undr)return VGA_UNDER;
    if(ital)return VGA_ITAL;
    return VGA_WHITE;
}

static void md_draw(const char*fname,int size,int cur,int bold,int ital,int undr){
    ed_draw_bar(0,fname,0x02);
    /* show active formatting in header */
    char fmtbar[VGA_COLS+1];
    memset_s(fmtbar,' ',VGA_COLS);fmtbar[VGA_COLS]=0;
    const char*hints="  Ctrl+B=Bold  Ctrl+I=Italic  Ctrl+U=Underline  ESC=save";
    int hl=strlen(hints);
    for(int i=0;i<hl&&i<VGA_COLS;i++) fmtbar[i]=hints[i];
    unsigned char attr=(0x02<<4)|0x0F;
    for(int c=0;c<VGA_COLS;c++) vga[c]=(unsigned short)fmtbar[c]|((unsigned short)attr<<8);

    int row=1,col=0;
    int cbold=0,cital=0,cundr=0;
    for(int i=0;i<=size&&row<VGA_ROWS-1;i++){
        if(i==size){if(i==cur)vga_put(row,col,'_',0x70);break;}
        unsigned char ch=(unsigned char)ed_buf[i];
        /* handle format markers */
        if(ch==MD_BOLD){cbold=!cbold;if(i==cur)vga_put(row,col,'B',0x70);continue;}
        if(ch==MD_ITAL){cital=!cital;if(i==cur)vga_put(row,col,'I',0x70);continue;}
        if(ch==MD_UNDR){cundr=!cundr;if(i==cur)vga_put(row,col,'U',0x70);continue;}
        unsigned char color;
        if(i==cur)color=0x70;
        else if(cbold)color=VGA_BOLD;
        else if(cundr)color=VGA_UNDER;
        else if(cital)color=VGA_ITAL;
        else color=VGA_WHITE;
        if(ch=='\n'){
            if(i==cur)vga_put(row,col,' ',0x70);
            while(col<VGA_COLS)vga_put(row,col++,' ',VGA_BLACK);
            row++;col=0;continue;
        }
        vga_put(row,col++,(char)ch,color);
        if(col>=VGA_COLS){col=0;row++;}
    }
    while(row<VGA_ROWS-1){while(col<VGA_COLS)vga_put(row,col++,' ',VGA_BLACK);col=0;row++;}
    /* status bar */
    char sbar[VGA_COLS+1];memset_s(sbar,' ',VGA_COLS);sbar[VGA_COLS]=0;
    sbar[1]='[';
    if(bold){sbar[2]='B';}else{sbar[2]='-';}
    if(ital){sbar[3]='I';}else{sbar[3]='-';}
    if(undr){sbar[4]='U';}else{sbar[4]='-';}
    sbar[5]=']';
    unsigned char sattr=(0x00<<4)|0x08;
    for(int c=0;c<VGA_COLS;c++) vga[(VGA_ROWS-1)*VGA_COLS+c]=(unsigned short)sbar[c]|((unsigned short)sattr<<8);
}

static int md_run(const char*fname,int size){
    int cur=size,bold=0,ital=0,undr=0;
    md_draw(fname,size,cur,bold,ital,undr);
    while(1){
        unsigned char sc=read_sc();
        if(sc==SC_LSHIFT||sc==SC_RSHIFT){shift_held=1;continue;}
        if(sc==(SC_LSHIFT|0x80)||sc==(SC_RSHIFT|0x80)){shift_held=0;continue;}
        if(sc==SC_LCTRL){ctrl_held=1;continue;}
        if(sc==(SC_LCTRL|0x80)){ctrl_held=0;continue;}
        if(sc&0x80)continue;
        if(sc==0x01)break; /* ESC */

        /* Ctrl+B/I/U toggles */
        if(ctrl_held){
            unsigned char marker=0;
            if(sc==0x30){marker=MD_BOLD;bold=!bold;}  /* B */
            if(sc==0x17){marker=MD_ITAL;ital=!ital;}  /* I */
            if(sc==0x16){marker=MD_UNDR;undr=!undr;}  /* U */
            if(marker&&size<(int)MAX_FILESIZE-1){
                for(int i=size;i>cur;i--)ed_buf[i]=ed_buf[i-1];
                ed_buf[cur]=(char)marker;size++;cur++;
            }
            md_draw(fname,size,cur,bold,ital,undr);
            continue;
        }

        if(sc==0x4B){if(cur>0)cur--;}
        else if(sc==0x4D){if(cur<size)cur++;}
        else if(sc==0x0E&&cur>0){for(int i=cur-1;i<size-1;i++)ed_buf[i]=ed_buf[i+1];size--;cur--;}
        else if(sc==0x1C&&size<(int)MAX_FILESIZE-1){for(int i=size;i>cur;i--)ed_buf[i]=ed_buf[i-1];ed_buf[cur]='\n';size++;cur++;}
        else{
            const char*map=shift_held?sc_hi:sc_lo;
            if(sc<(int)sizeof(sc_lo)&&map[sc]&&map[sc]!='\b'&&size<(int)MAX_FILESIZE-1){
                for(int i=size;i>cur;i--)ed_buf[i]=ed_buf[i-1];
                ed_buf[cur]=map[sc];size++;cur++;
            }
        }
        md_draw(fname,size,cur,bold,ital,undr);
    }
    return size;
}

/* ── Shell forward declaration ── */
static void run_cmd(void);
static char cmd[80];
static int  cmd_pos=0;

/* ── Script runner (.sh) ── */
static void sh_run(FEntry*e){
    if(!e->size){print("(empty script)\n");return;}
    static char sbuf[MAX_FILESIZE];
    memset_s(sbuf,0,MAX_FILESIZE);
    fe_read_data(e,sbuf);
    int i=0,sz=(int)e->size;
    print_color("Running script...\n",VGA_GRAY);
    while(i<sz){
        /* read one line into cmd */
        cmd_pos=0;
        memset_s(cmd,0,80);
        while(i<sz&&sbuf[i]!='\n'&&cmd_pos<79){
            cmd[cmd_pos++]=sbuf[i++];
        }
        if(i<sz&&sbuf[i]=='\n')i++;
        cmd[cmd_pos]=0;
        if(cmd_pos==0)continue;
        /* echo the line */
        print_color("  > ",VGA_GRAY);print(cmd);print("\n");
        run_cmd();
    }
    print_color("Script done.\n",VGA_LIME);
    cmd_pos=0;memset_s(cmd,0,80);
}

/* ── Shell ── */
static void prompt(void){
    print_color("\n",VGA_WHITE);
    print_color(cfg_prompt_name,cfg_prompt_color);
    print_color("> ",cfg_prompt_color);
}
static void print_int(int n){if(!n){putchar_color('0',VGA_GRAY);return;}char b[12];int bi=0;while(n>0){b[bi++]='0'+(n%10);n/=10;}for(int k=bi-1;k>=0;k--)putchar_color(b[k],VGA_GRAY);}
static void split_cmd(const char*in,char*verb,char*arg){int i=0;while(in[i]&&in[i]!=' '){verb[i]=in[i];i++;}verb[i]=0;if(in[i]==' ')i++;int j=0;while(in[i]){arg[j++]=in[i++];}arg[j]=0;}

static void run_cmd(void){
    if(!cmd_pos)return;
    char verb[80],arg[80];
    split_cmd(cmd,verb,arg);

    if(!ata_ready&&strcmp(verb,"help")!=0&&strcmp(verb,"clear")!=0&&strcmp(verb,"about")!=0&&strcmp(verb,"lime")!=0){
        print_color("No disk detected.\n",VGA_GRAY);return;
    }

    if(strcmp(verb,"help")==0){
        print_color("Commands:\n",VGA_LIME);
        print("  help           this list\n");
        print("  clear          clear screen\n");
        print("  about          about LimeOS\n");
        print("  lime           logo\n");
        print("  ls             list files\n");
        print("  touch <f>      create file (.txt .log .cfg .md .sh)\n");
        print("  open <f>       edit file (ESC saves)\n");
        print("  cat <f>        print file\n");
        print("  run <f>        run a .sh script\n");
        print("  rm <f>         delete file\n");
        print_color("  config.cfg     set prompt_name= and prompt_color=\n",VGA_GRAY);
    }
    else if(strcmp(verb,"clear")==0){clear_screen();}
    else if(strcmp(verb,"about")==0){
        print_color("LimeOS v0.6\n",VGA_LIME);
        print("Persistent LimeFS. .log .cfg .md .sh all active.\n");
        print_color(ata_ready?"Disk: online\n":"Disk: not found\n",ata_ready?VGA_LIME:VGA_GRAY);
    }
    else if(strcmp(verb,"lime")==0){
        print_color(
            "  ██╗     ██╗███╗   ███╗███████╗ ██████╗ ███████╗\n"
            "  ██║     ██║████╗ ████║██╔════╝██╔═══██╗██╔════╝\n"
            "  ██║     ██║██╔████╔██║█████╗  ██║   ██║███████╗\n"
            "  ██║     ██║██║╚██╔╝██║██╔══╝  ██║   ██║╚════██║\n"
            "  ███████╗██║██║ ╚═╝ ██║███████╗╚██████╔╝███████║\n"
            "  ╚══════╝╚═╝╚═╝     ╚═╝╚══════╝ ╚═════╝ ╚══════╝\n",
            VGA_LIME);
    }
    else if(strcmp(verb,"ls")==0){
        fs_read_hdr();
        int any=0;
        for(int i=0;i<MAX_FILES;i++){
            if(ft[i].used==0xAA){
                const char*ext=get_ext(ft[i].name);
                unsigned char col=VGA_WHITE;
                if(strcmp(ext,".txt")==0)col=VGA_WHITE;
                else if(strcmp(ext,".log")==0)col=VGA_GRAY;
                else if(strcmp(ext,".cfg")==0)col=0x0E; /* yellow */
                else if(strcmp(ext,".md")==0) col=VGA_CYAN;
                else if(strcmp(ext,".sh")==0) col=VGA_LIME;
                print("  ");print_color(ft[i].name,col);
                print_color("  (",VGA_GRAY);print_int((int)ft[i].size);print_color(" B)\n",VGA_GRAY);
                any=1;
            }
        }
        if(!any)print("  (no files)\n");
    }
    else if(strcmp(verb,"touch")==0){
        if(!arg[0]){print("Usage: touch <name>.<ext>\n");return;}
        if(!has_valid_ext(arg)){print_color("Error: ",VGA_GRAY);print("must include file type ");print_color("(.txt .log .cfg .md .sh)\n",VGA_CYAN);return;}
        fs_read_hdr();
        if(fe_find(arg)){print("Already exists.\n");return;}
        FEntry*e=fe_alloc();
        if(!e){print("Filesystem full!\n");return;}
        memset_s(e,0,sizeof(FEntry));
        strcpy_s(e->name,arg);
        e->used=0xAA;e->size=0;
        fs_write_hdr();
        print_color("Created: ",VGA_LIME);print_color(arg,VGA_CYAN);print("\n");
        log_append("created");
        /* append filename to log entry */
    }
    else if(strcmp(verb,"open")==0){
        if(!arg[0]){print("Usage: open <name>\n");return;}
        if(!has_valid_ext(arg)){print_color("Error: ",VGA_GRAY);print("must include file type ");print_color("(.txt .log .cfg .md .sh)\n",VGA_CYAN);return;}
        fs_read_hdr();
        FEntry*e=fe_find(arg);
        if(!e){print("Not found. Use touch first.\n");return;}
        memset_s(ed_buf,0,MAX_FILESIZE);
        if(e->size>0)fe_read_data(e,ed_buf);
        clear_screen();
        int newsize;
        const char*ext=get_ext(arg);
        if(strcmp(ext,".md")==0)
            newsize=md_run(arg,(int)e->size);
        else
            newsize=txt_run(arg,(int)e->size);
        fe_write_data(e,ed_buf,(unsigned int)newsize);
        /* reload config if it was config.cfg */
        if(strcmp(arg,"config.cfg")==0)cfg_load();
        clear_screen();
        print_color("Saved: ",VGA_LIME);print_color(arg,VGA_CYAN);
        print_color(" (",VGA_GRAY);print_int(newsize);print_color(" B)\n",VGA_GRAY);
        /* log the open */
        static char logline[48];
        memset_s(logline,0,48);
        int li=0;
        const char*pre="opened: ";
        while(pre[li]&&li<47){logline[li]=pre[li];li++;}
        int ni=0;while(arg[ni]&&li<47){logline[li++]=arg[ni++];}
        logline[li]=0;
        log_append(logline);
    }
    else if(strcmp(verb,"cat")==0){
        if(!arg[0]){print("Usage: cat <name>\n");return;}
        fs_read_hdr();
        FEntry*e=fe_find(arg);
        if(!e){print("Not found.\n");return;}
        if(!e->size){print("(empty)\n");return;}
        memset_s(ed_buf,0,MAX_FILESIZE);
        fe_read_data(e,ed_buf);
        const char*ext=get_ext(arg);
        if(strcmp(ext,".md")==0){
            /* render md markers */
            int bold=0,ital=0,undr=0;
            for(unsigned int i=0;i<e->size;i++){
                unsigned char c=(unsigned char)ed_buf[i];
                if(c==MD_BOLD){bold=!bold;print_color(bold?"[B]":"[/B]",VGA_CYAN);continue;}
                if(c==MD_ITAL){ital=!ital;print_color(ital?"[I]":"[/I]",VGA_CYAN);continue;}
                if(c==MD_UNDR){undr=!undr;print_color(undr?"[U]":"[/U]",VGA_CYAN);continue;}
                unsigned char col=bold?VGA_BOLD:undr?VGA_UNDER:ital?VGA_ITAL:VGA_WHITE;
                putchar_color((char)c,col);
            }
        } else {
            for(unsigned int i=0;i<e->size;i++)putchar_color(ed_buf[i],VGA_WHITE);
        }
        print("\n");
    }
    else if(strcmp(verb,"run")==0){
        if(!arg[0]){print("Usage: run <script.sh>\n");return;}
        fs_read_hdr();
        FEntry*e=fe_find(arg);
        if(!e){print("Not found.\n");return;}
        const char*ext=get_ext(arg);
        if(strcmp(ext,".sh")!=0){print("Only .sh files can be run.\n");return;}
        sh_run(e);
        static char logline[48];
        memset_s(logline,0,48);
        int li=0;const char*pre="ran script: ";
        while(pre[li]&&li<47){logline[li]=pre[li];li++;}
        int ni=0;while(arg[ni]&&li<47){logline[li++]=arg[ni++];}
        logline[li]=0;
        log_append(logline);
    }
    else if(strcmp(verb,"rm")==0){
        if(!arg[0]){print("Usage: rm <name>\n");return;}
        fs_read_hdr();
        FEntry*e=fe_find(arg);
        if(!e){print("Not found.\n");return;}
        static char logline[48];
        memset_s(logline,0,48);
        int li=0;const char*pre="deleted: ";
        while(pre[li]&&li<47){logline[li]=pre[li];li++;}
        int ni=0;while(arg[ni]&&li<47){logline[li++]=arg[ni++];}
        logline[li]=0;
        memset_s(e,0,sizeof(FEntry));
        fs_write_hdr();
        print_color("Deleted: ",VGA_LIME);print_color(arg,VGA_CYAN);print("\n");
        log_append(logline);
    }
    else{
        print("Unknown: ");print(verb);print_color("  (type 'help')\n",VGA_GRAY);
    }
}

/* ── Kernel entry ── */
void kernel_main(void){
    ata_init();
    fs_init();
    cfg_load();
    clear_screen();
    print_color(
        "  ██╗     ██╗███╗   ███╗███████╗ ██████╗ ███████╗\n"
        "  ██║     ██║████╗ ████║██╔════╝██╔═══██╗██╔════╝\n"
        "  ██║     ██║██╔████╔██║█████╗  ██║   ██║███████╗\n"
        "  ██║     ██║██║╚██╔╝██║██╔══╝  ██║   ██║╚════██║\n"
        "  ███████╗██║██║ ╚═╝ ██║███████╗╚██████╔╝███████║\n"
        "  ╚══════╝╚═╝╚═╝     ╚═╝╚══════╝ ╚═════╝ ╚══════╝\n",
        VGA_LIME);
    print_color("\n  v0.6 | ",VGA_WHITE);
    print_color(ata_ready?"Disk online.":"No disk.",ata_ready?VGA_LIME:VGA_GRAY);
    print_color("  Type 'help'.\n\n",VGA_WHITE);
    prompt();
    while(1){
        unsigned char sc=read_sc();
        if(sc==SC_LSHIFT||sc==SC_RSHIFT){shift_held=1;continue;}
        if(sc==(SC_LSHIFT|0x80)||sc==(SC_RSHIFT|0x80)){shift_held=0;continue;}
        if(sc==SC_LCTRL){ctrl_held=1;continue;}
        if(sc==(SC_LCTRL|0x80)){ctrl_held=0;continue;}
        if(sc&0x80)continue;
        const char*map=shift_held?sc_hi:sc_lo;
        char c=(sc<(int)sizeof(sc_lo))?map[sc]:0;
        if(!c)continue;
        boot_tick++;
        if(c=='\n'){
            print("\n");
            run_cmd();
            memset_s(cmd,0,80);cmd_pos=0;
            prompt();
        }
        else if(c=='\b'){if(cmd_pos>0){cmd[--cmd_pos]=0;putchar_color('\b',VGA_WHITE);}}
        else if(cmd_pos<79){cmd[cmd_pos++]=c;putchar_color(c,VGA_WHITE);}
    }
}
