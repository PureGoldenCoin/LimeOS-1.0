#!/bin/bash

cd "$(dirname "$0")"

make clean
make

qemu-system-i386 \
-cdrom limeos.iso \
-drive id=disk,file="$HOME/Desktop/SCREENSHOT 12.385.67/disk.img",format=raw,if=none \
-device ide-hd,drive=disk,bus=ide.0 \
-boot d