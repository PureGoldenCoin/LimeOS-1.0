; LimeOS - boot.asm
; Multiboot header + kernel entry point

MBALIGN  equ 1<<0
MEMINFO  equ 1<<1
MAGIC    equ 0x1BADB002
FLAGS    equ MBALIGN | MEMINFO
CHECKSUM equ -(MAGIC + FLAGS)

section .multiboot
align 4
    dd MAGIC
    dd FLAGS
    dd CHECKSUM

section .bss
align 16
stack_bottom:
    resb 4096           ; 4KB stack
stack_top:

section .text
global _start
extern kernel_main

_start:
    mov esp, stack_top  ; set up stack
    call kernel_main    ; jump to C kernel
    cli
.hang:
    hlt
    jmp .hang
